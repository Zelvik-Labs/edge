from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

root = Path.cwd()
source = root / '.local/perf-round4-workers'
dest = root / 'docs/evidence/io-wq-bounded-2026-11-02'
dest.mkdir(parents=True, exist_ok=True)
manifest = json.loads((source/'candidate-manifest.json').read_text())
for path, digest in manifest['sources'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == digest, path
cpu, resources = [], []
for concurrency in (1, 16):
    base = source/f'workers-c{concurrency}'
    assert json.loads((base/'summary.json').read_text())['all_passed']
    for name in ('summary','metadata','runs'):
        shutil.copyfile(base/f'{name}.json',dest/f'local-c{concurrency}-{name}.json')
    for r in json.loads((base/'runs.json').read_text()):
        assert r['passed'] and r['resource_checks']['passed']
        before,after=(r[f'cpu_{t}']['proc']['cpu'] for t in ('before','after'))
        delta=[y-x for x,y in zip(before,after)]
        cpu.append({'concurrency':concurrency,'round':r['round'],'engine':r['engine'],'steal_percent':100*delta[7]/sum(delta[:8]),'cpu_before':r['cpu_before'],'cpu_after':r['cpu_after']})
        log=(base/f"round-{r['round']}-{r['engine']}"/'stderr.log').read_text()
        rows=[]
        for line in log.splitlines():
            if line.startswith('SPLICE_RESOURCE '):
                m=re.fullmatch(r'SPLICE_RESOURCE engine=([\w-]+) concurrency=(\d+) completed_roundtrips=(\d+) fds=(\d+) threads=(.*)',line)
                assert m
                engine,c,trips,fds,threads=m.groups();threads=json.loads(threads)
                rows.append({'concurrency':int(c),'round':r['round'],'engine':engine,'completed_roundtrips':int(trips),'fds':int(fds),'threads':threads,'thread_count':len(threads),'io_wq_threads':sum(t.startswith('iou-wrk-') for t in threads)})
        assert len(rows)==3
        for size,row,affinity,report in zip((1024,65536,1048576),rows,r['resource_checks']['affinities'],r['resource_checks']['io_wq_reports']):
            row.update(bytes=size,affinity=affinity,io_wq_report=report)
            resources.append(row)
for name,value in [('local-cpu-summary',cpu),('local-resource-summary',resources)]:
    (dest/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
for name in ('candidate-manifest.json','validation.json','reverse-result.json','kernel-capabilities.json'):
    shutil.copyfile(source/name,dest/name)
patch=subprocess.check_output(['git','diff','--','crates/zelvik-edge-io','scripts/perf/compare-splice.py','.github/workflows/ci.yml'])
(source/'implementation.patch').write_bytes(patch)
shutil.copyfile(root/'scripts/perf/kernel-capability.c',source/'kernel-capability.c')
files={}
with zipfile.ZipFile(dest/'local-raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(source.rglob('*')):
        if not p.is_file() or 'bin' in p.relative_to(source).parts or p.name=='kernel-probe':continue
        name=p.relative_to(source).as_posix();b=p.read_bytes();z.writestr(name,b)
        files[name]=hashlib.sha256(b).hexdigest()
(dest/'local-archive-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256((dest/'local-raw.zip').read_bytes()).hexdigest(),'files':files},indent=2)+'\n')
print({'files':len(files),'cases':len(resources),'binary_sha256':manifest['binary_sha256'],'archive_bytes':(dest/'local-raw.zip').stat().st_size})
