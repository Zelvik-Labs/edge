use io_uring::{IoUring, Probe, opcode, types};
use std::io::{self, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};

fn pair() -> io::Result<(TcpStream, TcpStream)> {
    let listener = TcpListener::bind("127.0.0.1:0")?;
    let client = TcpStream::connect(listener.local_addr()?)?;
    Ok((client, listener.accept()?.0))
}

fn pipe() -> io::Result<(OwnedFd, OwnedFd)> {
    let mut fds = [0; 2];
    // SAFETY: fds provides two writable integers. Successful pipe2 gives
    // each descriptor a single owner below.
    if unsafe { libc::pipe2(fds.as_mut_ptr(), libc::O_CLOEXEC | libc::O_NONBLOCK) } < 0 {
        return Err(io::Error::last_os_error());
    }
    // SAFETY: pipe2 succeeded and neither descriptor has another owner.
    Ok(unsafe { (OwnedFd::from_raw_fd(fds[0]), OwnedFd::from_raw_fd(fds[1])) })
}

fn push(ring: &mut IoUring, entry: &io_uring::squeue::Entry) -> io::Result<()> {
    // SAFETY: all submitted operations use only owned descriptors kept
    // alive through their CQEs. No userspace data pointer is submitted.
    unsafe { ring.submission().push(entry) }
        .map_err(|_| io::Error::new(io::ErrorKind::WouldBlock, "submission queue full"))
}

fn splice(ring: &mut IoUring, from: i32, to: i32, bytes: u32, id: u64) -> io::Result<usize> {
    let entry = opcode::Splice::new(types::Fd(from), -1, types::Fd(to), -1, bytes)
        .flags(libc::SPLICE_F_MOVE | libc::SPLICE_F_NONBLOCK)
        .build()
        .user_data(id);
    push(ring, &entry)?;
    ring.submit_and_wait(1)?;
    let completion = ring
        .completion()
        .next()
        .ok_or_else(|| io::Error::other("missing splice CQE"))?;
    if completion.user_data() != id {
        return Err(io::Error::other("unexpected splice completion id"));
    }
    if completion.result() < 0 {
        return Err(io::Error::from_raw_os_error(-completion.result()));
    }
    Ok(completion.result() as usize)
}

fn run() -> io::Result<serde_json::Value> {
    let mut ring = IoUring::new(64)?;
    let mut probe = Probe::new();
    ring.submitter().register_probe(&mut probe)?;
    let capabilities = serde_json::json!({
        "splice": probe.is_supported(opcode::Splice::CODE),
        "poll_add": probe.is_supported(opcode::PollAdd::CODE),
        "async_cancel": probe.is_supported(opcode::AsyncCancel::CODE),
        "recv": probe.is_supported(opcode::Recv::CODE),
        "send": probe.is_supported(opcode::Send::CODE),
    });
    println!("{}", serde_json::json!({"phase":"registered_probe","capabilities":capabilities}));
    for code in [opcode::Splice::CODE, opcode::PollAdd::CODE, opcode::AsyncCancel::CODE] {
        if !probe.is_supported(code) {
            return Err(io::Error::new(io::ErrorKind::Unsupported, format!("required opcode {code} unsupported")));
        }
    }
    let (mut client, front) = pair()?;
    let (back, mut origin) = pair()?;
    front.set_nonblocking(true)?;
    back.set_nonblocking(true)?;
    let (read, write) = pipe()?;
    let payload = b"uring-splice-probe";
    client.write_all(payload)?;
    let mut sent = 0;
    while sent < payload.len() {
        let count = splice(&mut ring, front.as_raw_fd(), write.as_raw_fd(), (payload.len() - sent) as u32, 1)?;
        if count == 0 {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "early splice EOF"));
        }
        let mut remaining = count;
        while remaining != 0 {
            let written = splice(&mut ring, read.as_raw_fd(), back.as_raw_fd(), remaining as u32, 1)?;
            if written == 0 {
                return Err(io::Error::new(io::ErrorKind::WriteZero, "zero splice write"));
            }
            remaining -= written;
            sent += written;
        }
    }
    let mut received = vec![0; payload.len()];
    origin.read_exact(&mut received)?;
    if received != payload {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "splice payload mismatch"));
    }

    // The source is now idle. Arm a readiness request, cancel that exact
    // request, and consume both CQEs before releasing its descriptor.
    push(&mut ring, &opcode::PollAdd::new(types::Fd(front.as_raw_fd()), libc::POLLIN as u32).build().user_data(2))?;
    ring.submit()?;
    push(&mut ring, &opcode::AsyncCancel::new(2).build().user_data(3))?;
    ring.submit_and_wait(2)?;
    let mut cancelled_poll = false;
    let mut cancelled_request = false;
    for completion in ring.completion() {
        match (completion.user_data(), completion.result()) {
            (2, result) if result == -libc::ECANCELED => cancelled_poll = true,
            (3, 0) => cancelled_request = true,
            (id, result) => return Err(io::Error::other(format!("unexpected cancel CQE id={id} result={result}"))),
        }
    }
    if !cancelled_poll || !cancelled_request {
        return Err(io::Error::other("cancel CQEs incomplete"));
    }
    Ok(serde_json::json!({
        "passed":true,"capabilities":capabilities,"transferred_bytes":sent,
        "poll_cancelled":cancelled_poll,"cancel_acknowledged":cancelled_request,
        "features":{"fast_poll":ring.params().is_feature_fast_poll(),"nodrop":ring.params().is_feature_nodrop()},
        "sq_entries":ring.params().sq_entries(),"cq_entries":ring.params().cq_entries(),
    }))
}

fn main() {
    match run() {
        Ok(result) => println!("{result}"),
        Err(error) => {
            println!("{}", serde_json::json!({"passed":false,"error":error.to_string(),"kind":format!("{:?}",error.kind()),"errno":error.raw_os_error()}));
            std::process::exit(1);
        }
    }
}
