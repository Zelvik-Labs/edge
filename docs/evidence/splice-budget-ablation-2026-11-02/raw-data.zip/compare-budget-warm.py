import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("comparison", root.parents[1] / "scripts/perf/compare-splice.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
output = root / "budget-comparison-warm"
output.mkdir(exist_ok=False)
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
binaries = {
    "explicit_budget": (root / "bin/splice-baseline-rebuilt").resolve(),
    "tokio_budget_only": (root / "bin/splice-no-extra-budget").resolve(),
}
paths = [root / "compare-budget-warm.py", root / "splice-before.rs", root / "splice-candidate.rs", root.parents[1] / "crates/zelvik-edge-io/src/splice.rs"]
metadata = {
    "baseline_commit": "2df8b242b1b0d24f199e22592b6924e592f960a2",
    "scope": "readiness vs readiness; only explicit cooperative budget removed",
    "binaries": {name: {"path": str(path), "sha256": helper.sha256(path)} for name, path in binaries.items()},
    "sources": {str(path): helper.sha256(path) for path in paths},
    "cpus": sorted(os.sched_getaffinity(0)),
}
helper.write_json(output / "metadata.json", metadata)
records = []
for number in range(1, 4):
    order = list(binaries) if number % 2 else list(reversed(binaries))
    for label in order:
        directory = output / f"round-{number}-{label}"
        directory.mkdir()
        env = dict(os.environ, EDGE_SPLICE_BENCH_ENGINE="readiness", CRITERION_HOME=str(directory / "criterion"))
        command = [str(binaries[label]), "--bench", "--noplot"]
        record = {"round": number, "variant": label, "command": command, "cpu_before": helper.cpu_stat(), "started_unix": time.time()}
        with (directory / "stdout.log").open("w") as stdout, (directory / "stderr.log").open("w") as stderr:
            run = subprocess.run(command, env=env, stdout=stdout, stderr=stderr, timeout=180)
        record.update(returncode=run.returncode, cpu_after=helper.cpu_stat(), finished_unix=time.time())
        record["cases"] = [{"bytes": int(p.parent.parent.name), "mean_ns": json.loads(p.read_text())["mean"]["point_estimate"]} for p in sorted((directory / "criterion").glob("**/new/estimates.json"))]
        record["passed"] = run.returncode == 0 and sorted(c["bytes"] for c in record["cases"]) == [1024, 65536, 1048576]
        records.append(record)
        helper.write_json(output / "runs.json", records)
        print(number, label, record["passed"], flush=True)
        if not record["passed"]:
            raise SystemExit(1)
metadata["unchanged"] = all(helper.sha256(p) == metadata["sources"][str(p)] for p in paths) and all(helper.sha256(p) == metadata["binaries"][name]["sha256"] for name, p in binaries.items())
helper.write_json(output / "metadata.json", metadata)
if not metadata["unchanged"]:
    raise SystemExit(1)
