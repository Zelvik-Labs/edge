import json,os,subprocess,time
from pathlib import Path
root=Path.cwd();local=root/'.local/five-priorities';out=local/'capacity-continuous-2g';log=local/'capacity-continuous-2g.log';samples=local/'capacity-continuous-samples.jsonl'
command=['python3','scripts/perf/protocol_state_matrix.py','--target','edge','--output',str(out),'--tls',str(local/'admission-local-tls'),'--client',str(local/'native-admission-probe/extracted/protocol-state-client'),'--edge-binary',str(local/'native-confirmation-probe-binaries/extracted/target/release/Zelvik-Edge'),'--controller',str(local/'native-admission-probe-binaries/extracted/target/release/examples/issue34-controller'),'--edge-image','edge-hotpath-final:20261101','--edge-backend','tokio-quiche-native','--transport-profile','matched','--address-validation','off','--payload-size','1024','--concurrency','32','--fresh-requests','262144','--seconds','3','--repeats','1','--protocols','h3','--states','hit','--connections','fresh']
env=os.environ.copy();env['PATH']=str(local/'admission-local-bin')+':'+env['PATH']
(local/'capacity-continuous-command.json').write_text(json.dumps(command,indent=2)+'\n')
with log.open('x') as output,samples.open('x') as sample:
 process=subprocess.Popen(command,env=env,stdout=output,stderr=subprocess.STDOUT)
 while process.poll() is None:
  names=subprocess.check_output(['/usr/local/bin/docker','ps','--format','{{.Names}}'],text=True).splitlines()
  names=[name for name in names if name.startswith('edge-state-') and name.endswith('-edge')]
  assert len(names)<=1,names
  for name in names:
   row={'time':time.time(),'container':name}
   top=subprocess.run(['/usr/local/bin/docker','top',name,'-eo','pid,comm,rss,nlwp'],capture_output=True,text=True)
   row.update(top_returncode=top.returncode,processes=top.stdout,error=top.stderr)
   if top.returncode==0:
    for line in top.stdout.splitlines()[1:]:
     fields=line.split()
     if len(fields)==4 and fields[1]=='Zelvik-Edge':
      row.update(node_pid=int(fields[0]),node_rss_kib=int(fields[2]),node_threads=int(fields[3]))
      try:row['node_fd_count']=len(list(Path('/proc',fields[0],'fd').iterdir()))
      except OSError as error:row['fd_observation_error']=str(error)
   sample.write(json.dumps(row)+'\n');sample.flush()
  time.sleep(10)
 code=process.wait()
print(json.dumps({'driver_exit':code,'samples':str(samples)}))
raise SystemExit(code)
