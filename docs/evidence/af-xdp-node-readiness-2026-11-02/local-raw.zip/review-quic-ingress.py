import hashlib,json,pathlib,re
root=pathlib.Path('.local/perf-round7-node')
old=(root/'quic-demux-before.rs').read_text();new=pathlib.Path('src/quic_udp_demux.rs').read_text()
def body(source,token):
    a=source.index(token);a=source.index('{',a);i=a+1;depth=1
    while depth:
        depth+=(source[i]=='{')-(source[i]=='}');i+=1
    return source[a+1:i-1]
def norm(source):
    text=re.sub(r'\s+','',re.sub(r'//[^\n]*','',source))
    return text.replace(',}', '}').replace(',)', ')')
a=body(old,'    async fn process_datagram_with_downstream(')
b=body(new,'    async fn process_datagram_with_ingress_source(')
i=a.index('        let ingress = MEMORY_GOVERNOR.quic_ingress_snapshot();')
j=a.index('        let max_new_routes_per_ip',i)
materialization=a[i:j]
replacement='let QuicIngressObservation {ingress, pressure_level} = ingress_source.observe(shared);let max_routes_per_port=ingress.route_limit;'
assert norm(a[:i]+replacement+a[j:])==norm(b), 'Core logic changed outside observation materialization'
expected=materialization.replace('        let max_routes_per_port = ingress.route_limit;\n','').replace('            max_routes_per_port,','            ingress.route_limit,')+'QuicIngressObservation {ingress,pressure_level}'
actual=body(new,'            Self::Governor =>')
assert norm(expected)==norm(actual), 'Production observation composition changed'
(root/'quic-ingress-core-review.json').write_text(json.dumps({'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest(),'normalized_core_body_matches':True,'production_observation_body_matches':True,'test_only_fixed_variant':True,'normalization':'whitespace, line comments and optional trailing commas','scope':'same live snapshot, hysteresis/aggregate/kernel-pressure composition, blocked-client ordering and admission/routing checks; fixed complete observations only in unit tests'},indent=2)+'\n')
print('Core and live observation review passed')
