import hashlib,json,pathlib
base=pathlib.Path('/workspace/.cloudsidra-setup/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tokio-1.53.1/src/io')
needles={'async_fd.rs':['pub async fn readable<','self.ready(Interest::READABLE).await'],
         'ready.rs':['pub(crate) fn from_interest','if interest.is_error()'],
         'interest.rs':['pub const ERROR: Interest','Interest::READABLE => Ready::READABLE | Ready::READ_CLOSED']}
result={'tokio':'1.53.1','scope':'read-only source evidence; no dependency edits','files':{}}
for name,patterns in needles.items():
    path=base/name
    source=path.read_bytes()
    lines=source.decode().splitlines()
    excerpts=[]
    for index,line in enumerate(lines):
        if any(pattern in line for pattern in patterns):
            excerpts.append({'line':index+1,'excerpt':'\n'.join(lines[max(0,index-1):index+5])})
    result['files'][name]={'sha256':hashlib.sha256(source).hexdigest(),'excerpts':excerpts}
pathlib.Path('.local/perf-round7-node/tokio-error-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
