Next source-backed optimization candidates (not implementation or measurement):

- src/xdp/linux.rs queue poll_raw_once calls parse_l4_packet(frame).is_some() solely
  for parsed/parse_error counters before making frame.to_vec(). The bridge reads
  only packets/rx_observed_empty from those stats, then calls parse_proxy_frame.
- src/xdp/af_xdp/parser.rs parse_l4_packet creates owned Bytes payloads for both
  TCP and UDP. The statistics check can therefore allocate/copy and immediately
  discard payloads. parse_proxy_frame then repeats validation and makes another
  owned IP/UDP copy; UDP also parses link/header again.
- Potential stage: borrowed validated packet views so counters do not construct
  payloads, preserving exact malformed/checksum/fragment/IPv6/VLAN semantics;
  then parse once before returning RX frames to fill, with copies only for data
  that must outlive UMEM RX ownership or be steered across workers.
- Do not drop wire checksum validation, packet counters, ICMP/PMTU handling,
  worker steering, or users' configuration to make the path faster. Require
  differential adversarial parsing cases and allocation/per-packet benchmarks.
- Separate from current readiness integration CI. No throughput gain claimed.

Lifecycle follow-up to verify with fault injection (not yet a reproduced bug):
- spawn_queue_reactors sends ready before run_queue_bridge_loop constructs wake
  worker/readiness. proxy_xsk_ready accepts ready OR faulted queues for partial
  survival, with no explicit at-least-one-ready condition. enable_proxy_redirect
  later clears proxy fallback detail. Verify zero-survivor/startup-init failure
  does not falsely report global readiness; preserve surviving queues' operation.
- Prebuilt smoke still requires cargo unconditionally. sudo usually strips the
  toolchain PATH, even when XDP_SMOKE_SKIP_BUILD=1. If native CI fails at missing
  cargo, make only the build-time prerequisite conditional (no validation skip).

Concrete next borrowed-parser gate:
- Frame corpus: TCP ACK/SYN/options/data and UDP, payload0/64/1024/MTU,
  IPv4+6, zero/one/two VLANtags, v6extensions, malformed/truncated/fragmented,
  checksumcorruption. Count and classification must match existing oracle.
- Keep owned public parse_l4_packet API; internal validated view borrows payload.
  Construct Bytes only when ownership is required. Stats uses borrowed view.
  Empty TCP/UDP payload already uses nonallocating Bytes, so do not claim one
  allocation removed for all packets; measure each frame class separately.
- Count allocations separately from timing to avoid allocatorinstrumentation
  driving latency; then pairedrelease timing equalCPUbudget/body/countchecks.
- Preserve unknown-nonSYN filter, node-dial registry, TCP workersteering and
  PMTU parsing. A later parse-before-frame-copy change needs typed ownedhandoff
  for crossworker frames and must not hold UMEM while remoteapp tasks stall.

New H3 source finding, NOT implemented:
- native_h3_route couples pure-H3 port selection to Normal pressure. Elevated,
  High or Critical switches even a no-forwarding H3-only port back through
  classify_new_route and QUIC ClientHello fragment decrypt/reassembly.
- Potential separate pure-H3 routing decision from pressure admission policy:
  Quinn owns crypto/ALPN/Retry; retain adaptive per-IP windows, total routes,
  bounded queue/bytes, all errors/metrics, malformed/wrong-ALPN behavior.
- Must review endpoint Retry/connection admission, pending-vs-route memory and
  fragmentedInitial behavior before adopting. Compare valid/invalid traffic,
  many clients behind NAT and allpressurelevels. No high-pressure bypass.
