import pathlib,re
p=pathlib.Path('src/memory_shed.rs');s=p.read_text()
a=s.index('/// Keepalive suppression flag, read once');b=s.index('/// Hot-path read:',a)
block=s[a:b]
items=re.findall(r'static ([A-Z_]+): (AtomicBool|AtomicU64) = ([^;]+);',block)
assert len(items)==10
fields=re.sub(r'static ([A-Z_]+): (AtomicBool|AtomicU64) = [^;]+;',lambda m:f'{m[1].lower()}: {m[2]},',block)
replacement='// The process uses one state; tests own separate instances so real pressure\n// observations cannot reset their synthetic-time episodes.\nstruct ShedState {\n'+''.join('    '+line+'\n' for line in fields.rstrip().splitlines())+'}\n\nimpl ShedState {\n    const fn new() -> Self {\n        Self {\n'+''.join(f'            {name.lower()}: {init},\n' for name,typ,init in items)+'''        }
    }

    #[inline]
    fn keepalive_active(&self) -> bool {
        self.keepalive_shed_active.load(Ordering::Relaxed)
    }

    #[inline]
    fn note_keepalive_shed(&self) {
        self.shed_keepalive_marked.fetch_add(1, Ordering::Relaxed);
    }
}

static SHED_STATE: ShedState = ShedState::new();

'''
s=s[:a]+replacement+s[b:]
s=s.replace('    KEEPALIVE_SHED_ACTIVE.load(Ordering::Relaxed)\n','    SHED_STATE.keepalive_active()\n',1)
s=s.replace('    SHED_KEEPALIVE_MARKED.fetch_add(1, Ordering::Relaxed);\n','    SHED_STATE.note_keepalive_shed();\n',1)
s=s.replace('pub fn shed_stats() -> ShedStats {','pub fn shed_stats() -> ShedStats {\n    shed_stats_for(&SHED_STATE)\n}\n\nfn shed_stats_for(state: &ShedState) -> ShedStats {',1)
s=s.replace('keepalive_shed_active: shed_keepalive_active(),','keepalive_shed_active: state.keepalive_active(),',1)
s=s.replace('pub fn note_reclaim_outcome(ineffective: bool, now_ms: u64) {','pub fn note_reclaim_outcome(ineffective: bool, now_ms: u64) {\n    note_reclaim_outcome_for(&SHED_STATE, ineffective, now_ms);\n}\n\nfn note_reclaim_outcome_for(state: &ShedState, ineffective: bool, now_ms: u64) {',1)
s=s.replace('    observe_pressure_with_source(level, now_ms, current_account_inputs);','    observe_pressure_with_source(&SHED_STATE, level, now_ms, current_account_inputs);',1)
s=s.replace('fn observe_pressure_with_source<F>(level: MemoryPressureLevel, now_ms: u64, account: F)','fn observe_pressure_with_source<F>(state: &ShedState, level: MemoryPressureLevel, now_ms: u64, account: F)',1)
s=s.replace('fn record_fresh_critical_sample(now_ms: u64)', 'fn record_fresh_critical_sample(state: &ShedState, now_ms: u64)',1)
s=s.replace('if !record_fresh_critical_sample(now_ms)', 'if !record_fresh_critical_sample(state, now_ms)',1)
s=s.replace('fn reset_critical_episode()', 'fn reset_critical_episode(state: &ShedState)',1)
s=s.replace('            reset_critical_episode();','            reset_critical_episode(state);')
s=s.replace('fn observe_pressure_with(level: MemoryPressureLevel, now_ms: u64, account: AccountPressureInputs)', 'fn observe_pressure_with(state: &ShedState, level: MemoryPressureLevel, now_ms: u64, account: AccountPressureInputs)',1)
s=s.replace('    observe_pressure_with_source(level, now_ms, || account);','    observe_pressure_with_source(state, level, now_ms, || account);',1)
a=s.index('#[cfg(test)]\nfn reset_test_state()');b=s.index('#[cfg(test)]\nmod tests',a);s=s[:a]+s[b:]
for name,typ,init in items: s=re.sub(r'\b'+name+r'\b','state.'+name.lower(),s)
a=s.index('#[cfg(test)]\nmod tests');before,tests=s[:a],s[a:]
tests=tests.replace('fn drive_sustained_critical(start_ms: u64, account: AccountPressureInputs)', 'fn drive_sustained_critical(state: &ShedState, start_ms: u64, account: AccountPressureInputs)')
tests=tests.replace('observe_pressure_with(', 'observe_pressure_with(&state, ')
a=tests.index('    fn drive_sustained_critical(');b=tests.index('    #[test]',a)
tests=tests[:a]+tests[a:b].replace('observe_pressure_with(&state,','observe_pressure_with(state,')+tests[b:]
tests=tests.replace('reset_test_state();','let state = ShedState::new();')
tests=re.sub(r'(?<!fn )\bdrive_sustained_critical\(', 'drive_sustained_critical(&state, ',tests)
tests=tests.replace('note_reclaim_outcome(', 'note_reclaim_outcome_for(&state, ')
tests=tests.replace('shed_stats()', 'shed_stats_for(&state)')
tests=tests.replace('shed_keepalive_active()', 'state.keepalive_active()')
tests=tests.replace('note_keepalive_shed();', 'state.note_keepalive_shed();')
p.write_text(before+tests)
